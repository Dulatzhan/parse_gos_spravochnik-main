package main

import (
	"github.com/Akanibekuly/parse_gos_spravochnik/cmd"
)

func main() {
	cmd.Execute()
}
