package cmd

import (
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/Akanibekuly/parse_gos_spravochnik/internal/handlers/rest"
	"github.com/Akanibekuly/parse_gos_spravochnik/internal/models"
	"github.com/Akanibekuly/parse_gos_spravochnik/internal/zap"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

func Execute() {
	var err error
	debug := viper.GetBool("DEBUG")

	loadConf()
	app := struct {
		restApi *rest.St
		lg      *zap.St
	}{}
	if debug {
		gin.SetMode(gin.DebugMode)
	}

	app.lg, err = zap.New(viper.GetString("LOG_LEVEL"), debug, false)
	if err != nil {
		log.Fatal(err)
	}

	uriMap := make(map[string]string, 6)
	uriMap["all"] = viper.GetString("all")
	uriMap["rnu"] = viper.GetString("rnu")
	uriMap["ref_enstru"] = viper.GetString("ref_enstru")
	uriMap["ref_ekrb"] = viper.GetString("ref_ekrb")
	uriMap["ref_fkrb_program"] = viper.GetString("ref_fkrb_program")
	uriMap["ref_fkrb_subprogram"] = viper.GetString("ref_fkrb_subprogram")


	restApiEChan := make(chan error, 1)
	app.restApi = rest.New(
		app.lg,
		viper.GetString("HTTP_LISTEN"),
		restApiEChan,
		&models.Config{
			UriMap: uriMap,
			URL:    viper.GetString("goszakup_url"),
			Token:  viper.GetString("bearer_token"),
		},
	)

	app.restApi.Start()

	stopSignalChan := make(chan os.Signal, 1)
	signal.Notify(stopSignalChan, os.Interrupt, syscall.SIGTERM, syscall.SIGINT)

	var exitCode int

	select {
	case <-stopSignalChan:
	case <-restApiEChan:
		exitCode = 1
	}

	app.lg.Infow("Shutting down...")

	err = app.restApi.Shutdown(20 * time.Second)
	if err != nil {
		app.lg.Errorw("Fail to shutdown http-api", err)
		exitCode = 1
	}

	os.Exit(exitCode)
}

func loadConf() {
	viper.SetDefault("debug", "false")
	viper.SetDefault("log_level", "info")

	confFilePath := os.Getenv("CONF_PATH")
	if confFilePath == "" {
		confFilePath = "conf.yml"
	}
	viper.SetConfigFile(confFilePath)
	_ = viper.ReadInConfig()

	viper.AutomaticEnv()
}
