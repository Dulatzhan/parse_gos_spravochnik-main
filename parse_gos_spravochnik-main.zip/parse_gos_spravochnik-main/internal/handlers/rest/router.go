package rest

import "github.com/gin-gonic/gin"

func (a *St) router() *gin.Engine {
	router := gin.Default()

	router.GET("/ref_enstru", a.EnstruGet)
	router.GET("/ref_ekrb", a.EkrbGet)
	router.GET("/ref_fkrb_program", a.FkrbProgramGet)
	router.GET("/ref_fkrb_subprogram", a.FkrbSubprogramGet)
	router.GET("/all", a.SubjectGet)
	router.GET("/rnu", a.RnuGet)
	return router
}
