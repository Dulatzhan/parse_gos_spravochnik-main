package rest

import (
	"crypto/tls"
	"encoding/csv"
	"encoding/json"
	"net/http"
	"os"
	//"strconv"
	"time"

	"github.com/Akanibekuly/parse_gos_spravochnik/internal/models"
	"github.com/gin-gonic/gin"
)

func (a *St) SubjectGet(c *gin.Context) {
	name := "all"
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	url := a.config.URL + a.config.UriMap[name] + "?limit=500"
	data, err := a.DoReqeust(url, client)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
			"Error": err,
			"Data":  string(data),
		})
		return
	}

	resp := &models.SubjectRespSt{}
	err = json.Unmarshal(data, resp)
	if err != nil {
		a.lg.Error(err)
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	file, err := os.Create("./" + name + ".csv")
	if err != nil {
		a.lg.Error(err)
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{
		"pid", // - ID участника
		"bin", // - БИН
		"iin", // - ИИН
		"inn", //- ИНН
		"unp", //- УНП
		"regdate", // - Дата свидетельства о государственной регистрации
		"crdate", //- Дата регистрации
		"index_date", //- Дата индексации
		"number_reg", //- Номер свидетельства о государственной регистрации
		"series", //- Серия свидетельства (для ИП)
		"name_ru", //- Наименование на русском языке
		"name_kz", //- Наименование на казахском языке
		"full_name_ru", //- Полное наименование на русском языке
		"full_name_kz", //- Полное наименование на казахском языке
		"country_code", //- Страна по ЭЦП
		"customer", //- Флаг Заказчик (1 - да, 0 - Нет)
		"organizer", //- Флаг Организатор (1 - да, 0 - Нет)
		"mark_national_company", //- Флаг Национальная компания (1 - да, 0 - Нет)
		"ref_kopf_code", //- Код КОПФ
		"mark_assoc_with_disab", //- Флаг Объединение инвалидов (1 - да, 0 - Нет)
		"system_id", //- ИД Системы
		"supplier", //- Флаг Поставщик (1 - да, 0 - Нет)
		"type_supplier", // - Тип поставщика (1 - юридическое лицо, 2 - физическое лицо, 3 - ИП)
		"krp_code",  //- Размерность предприятия (КРП)
		"oked_list", //- ОКЭД
		"kse_code", //- Код сектора экономики
		"mark_world_company", //- Флаг Международная организация (1 - да, 0 - Нет)
		"mark_state_monopoly", //- Флаг Субъект государственной монополии (1 - да, 0 - Нет)
		"mark_natural_monopoly", // - Флаг Субъект естественной монополии (1 - да, 0 - Нет)
		"mark_patronymic_producer",  //- Флаг Отечественный товаропроизводитель (1 - да, 0 - Нет)
		"mark_patronymic_supplyer", //- Флаг Отечественный поставщик (1 - да, 0 - Нет)
		"mark_small_employer", //- Флаг Субъект малого предпринимательства (СМП) (1 - да, 0 - Нет)
		"is_single_org",  //- Флаг Единый организатор (1 - да, 0 - Нет)
		"email", //- E-Mail
		"phone", //- Телефон
		"website", //- Web сайт
		"last_update_date", //- Дата последнего редактирования
		"qvazi", //- Флаг Квазисектора
		"year", //- Год регистрации
		"mark_resident", //- Флаг резидента
		})
	for _, item := range resp.Items {
		row := []string{
			item.Pid, // - ID участника
			item.Bin, // - БИН
			item.Iin, // - ИИН
			item.Inn, //- ИНН
			item.Unp, //- УНП
			item.Regdate, // - Дата свидетельства о государственной регистрации
			item.Crdate, //- Дата регистрации
			item.Index_date, //- Дата индексации
			item.Number_reg, //- Номер свидетельства о государственной регистрации
			item.Series, //- Серия свидетельства (для ИП)
			item.Name_ru, //- Наименование на русском языке
			item.Name_kz, //- Наименование на казахском языке
			item.Full_name_ru, //- Полное наименование на русском языке
			item.Full_name_kz, //- Полное наименование на казахском языке
			item.Country_code, //- Страна по ЭЦП
			item.Customer, //- Флаг Заказчик (1 - да, 0 - Нет)
			item.Organizer, //- Флаг Организатор (1 - да, 0 - Нет)
			item.Mark_national_company, //- Флаг Национальная компания (1 - да, 0 - Нет)
			item.Ref_kopf_code, //- Код КОПФ
			item.Mark_assoc_with_disab, //- Флаг Объединение инвалидов (1 - да, 0 - Нет)
			item.System_id, //- ИД Системы
			item.Supplier, //- Флаг Поставщик (1 - да, 0 - Нет)
			item.Type_supplier, // - Тип поставщика (1 - юридическое лицо, 2 - физическое лицо, 3 - ИП)
			item.Krp_code,  //- Размерность предприятия (КРП)
			item.Oked_list, //- ОКЭД
			item.Kse_code, //- Код сектора экономики
			item.Mark_world_company, //- Флаг Международная организация (1 - да, 0 - Нет)
			item.Mark_state_monopoly, //- Флаг Субъект государственной монополии (1 - да, 0 - Нет)
			item.Mark_natural_monopoly, // - Флаг Субъект естественной монополии (1 - да, 0 - Нет)
			item.Mark_patronymic_producer,  //- Флаг Отечественный товаропроизводитель (1 - да, 0 - Нет)
			item.Mark_patronymic_supplyer, //- Флаг Отечественный поставщик (1 - да, 0 - Нет)
			item.Mark_small_employer, //- Флаг Субъект малого предпринимательства (СМП) (1 - да, 0 - Нет)
			item.Is_single_org,  //- Флаг Единый организатор (1 - да, 0 - Нет)
			item.Email, //- E-Mail
			item.Phone, //- Телефон
			item.Website, //- Web сайт
			item.Last_update_date, // - Дата последнего редактирования
			item.Qvazi, //- Флаг Квазисектора
			item.Year, //- Год регистрации
			item.Mark_resident, //- Флаг резидента
			}
		writer.Write(row)
	}

	// ссылка на след запрос не должен пустым даже если оно пусто то по общему количеству
	// запросов
	for i := 0; *resp.NextPage != "" && i < resp.Total; i++ {
		data, err = a.DoReqeust(a.config.URL+*resp.NextPage, client)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
				"Error": err,
				"Data":  resp,
			})
			return
		}

		err = json.Unmarshal(data, resp)
		if err != nil {
			a.lg.Error(err, data)
			c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
				"Error": err,
				"Data":  string(data),
			})
			return
		}

		for _, item := range resp.Items {
			row := []string{
				item.Pid, // - ID участника
				item.Bin, // - БИН
				item.Iin, // - ИИН
				item.Inn, //- ИНН
				item.Unp, //- УНП
				item.Regdate, // - Дата свидетельства о государственной регистрации
				item.Crdate, //- Дата регистрации
				item.Index_date, //- Дата индексации
				item.Number_reg, //- Номер свидетельства о государственной регистрации
				item.Series, //- Серия свидетельства (для ИП)
				item.Name_ru, //- Наименование на русском языке
				item.Name_kz, //- Наименование на казахском языке
				item.Full_name_ru, //- Полное наименование на русском языке
				item.Full_name_kz, //- Полное наименование на казахском языке
				item.Country_code, //- Страна по ЭЦП
				item.Customer, //- Флаг Заказчик (1 - да, 0 - Нет)
				item.Organizer, //- Флаг Организатор (1 - да, 0 - Нет)
				item.Mark_national_company, //- Флаг Национальная компания (1 - да, 0 - Нет)
				item.Ref_kopf_code, //- Код КОПФ
				item.Mark_assoc_with_disab, //- Флаг Объединение инвалидов (1 - да, 0 - Нет)
				item.System_id, //- ИД Системы
				item.Supplier, //- Флаг Поставщик (1 - да, 0 - Нет)
				item.Type_supplier, // - Тип поставщика (1 - юридическое лицо, 2 - физическое лицо, 3 - ИП)
				item.Krp_code,  //- Размерность предприятия (КРП)
				item.Oked_list, //- ОКЭД
				item.Kse_code, //- Код сектора экономики
				item.Mark_world_company, //- Флаг Международная организация (1 - да, 0 - Нет)
				item.Mark_state_monopoly, //- Флаг Субъект государственной монополии (1 - да, 0 - Нет)
				item.Mark_natural_monopoly, // - Флаг Субъект естественной монополии (1 - да, 0 - Нет)
				item.Mark_patronymic_producer,  //- Флаг Отечественный товаропроизводитель (1 - да, 0 - Нет)
				item.Mark_patronymic_supplyer, //- Флаг Отечественный поставщик (1 - да, 0 - Нет)
				item.Mark_small_employer, //- Флаг Субъект малого предпринимательства (СМП) (1 - да, 0 - Нет)
				item.Is_single_org,  //- Флаг Единый организатор (1 - да, 0 - Нет)
				item.Email, //- E-Mail
				item.Phone, //- Телефон
				item.Website, //- Web сайт
				item.Last_update_date, // - Дата последнего редактирования
				item.Qvazi, //- Флаг Квазисектора
				item.Year, //- Год регистрации
				item.Mark_resident, //- Флаг резидента,
			}
			writer.Write(row)
		}

		time.Sleep(time.Second * 1)
	}

	c.Header("Content-Description", "File Transfer")
	c.Header("Content-Transfer-Encoding", "binary")
	c.Header("Content-Disposition", "attachment; filename="+name+".csv")
	c.Header("Content-Type", "application/octet-stream")
	c.File("./" + name + ".csv")
	c.Status(http.StatusOK)
}
