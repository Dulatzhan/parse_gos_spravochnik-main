package rest

import (
	"crypto/tls"
	"encoding/csv"
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/Akanibekuly/parse_gos_spravochnik/internal/models"
	"github.com/gin-gonic/gin"
)

func (a *St) EkrbGet(c *gin.Context) {
	name := "ref_ekrb"
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	url := a.config.URL + a.config.UriMap[name] + "?limit=500"
	data, err := a.DoReqeust(url, client)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
			"Error": err,
			"Data":  string(data),
		})
		return
	}

	resp := &models.EkrbRespSt{}
	err = json.Unmarshal(data, resp)
	if err != nil {
		a.lg.Error(err)
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	file, err := os.Create("./" + name + ".csv")
	if err != nil {
		a.lg.Error(err)
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{
		"code",
		"name_ru",
		"name_kz",
		"id"})
	for _, item := range resp.Items {
		row := []string{
			item.Code,
			item.NameRU,
			item.NameKZ,
			strconv.Itoa(item.ID),
		}
		writer.Write(row)
	}

	// ссылка на след запрос не должен пустым даже если оно пусто то по общему количеству
	// запросов
	for i := 0; *resp.NextPage != "" && i < resp.Total; i++ {
		data, err = a.DoReqeust(a.config.URL+*resp.NextPage, client)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
				"Error": err,
				"Data":  resp,
			})
			return
		}

		err = json.Unmarshal(data, resp)
		if err != nil {
			a.lg.Error(err, data)
			c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
				"Error": err,
				"Data":  string(data),
			})
			return
		}

		for _, item := range resp.Items {
			row := []string{
				item.Code,
				item.NameRU,
				item.NameKZ,
				strconv.Itoa(item.ID),
			}
			writer.Write(row)
		}

		time.Sleep(time.Second * 1)
	}

	c.Header("Content-Description", "File Transfer")
	c.Header("Content-Transfer-Encoding", "binary")
	c.Header("Content-Disposition", "attachment; filename="+name+".csv")
	c.Header("Content-Type", "application/octet-stream")
	c.File("./" + name + ".csv")
	c.Status(http.StatusOK)
}
