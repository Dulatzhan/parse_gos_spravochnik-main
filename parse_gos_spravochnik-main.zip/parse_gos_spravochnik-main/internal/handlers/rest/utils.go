package rest

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

func (a *St) DoReqeust(url string, client *http.Client) (data []byte, err error) {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		a.lg.Error(err)
		return
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+a.config.Token)

	resp, err := client.Do(req)
	if err != nil {
		a.lg.Error(err)
		log.Println(err)
		return
	}
	defer resp.Body.Close()

	data, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		a.lg.Error(err)
		return
	}

	if resp.StatusCode != 200 {
		return data, fmt.Errorf("error status: %d", resp.StatusCode)
	}

	return data, nil
}
