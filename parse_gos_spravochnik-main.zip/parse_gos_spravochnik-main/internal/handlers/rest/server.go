package rest

import (
	"context"
	"net/http"
	"time"

	"github.com/Akanibekuly/parse_gos_spravochnik/internal/interfaces"
	"github.com/Akanibekuly/parse_gos_spravochnik/internal/models"
)

type St struct {
	lg     interfaces.Logger
	server *http.Server
	eChan  chan<- error
	config *models.Config
}

func New(
	lg interfaces.Logger,
	listen string,
	eChan chan<- error,
	config *models.Config,
) *St {
	api := &St{
		lg:     lg,
		eChan:  eChan,
		config: config,
	}

	api.server = &http.Server{
		Addr:    listen,
		Handler: api.router(),
	}
	return api
}

func (a *St) Start() {
	go func() {
		a.lg.Infow("Start rest-api", "addr", a.server.Addr)

		err := a.server.ListenAndServe()
		if err != nil && err != http.ErrServerClosed {
			a.lg.Errorw("Http server closed", err)
			a.eChan <- err
		}
	}()
}

func (a *St) Shutdown(timeout time.Duration) error {
	ctx, ctxCancel := context.WithTimeout(context.Background(), timeout)
	defer ctxCancel()

	return a.server.Shutdown(ctx)
}
