package models

type Config struct {
	URL    string
	UriMap map[string]string
	Token  string
}
