package models

type FkrbProgram struct {
	ID     int    `json:"id"`
	Prg    string `json:"prg"`
	NameRU string `json:"name_ru"`
	NameKZ string `json:"name_kz"`
	Code   string `json:"code"`
}

type FkrbProgramResp struct {
	Total    int            `json:"total"`
	Limit    int            `json:"limit"`
	NextPage *string        `json:"next_page"`
	Items    []*FkrbProgram `json:"items"`
}
