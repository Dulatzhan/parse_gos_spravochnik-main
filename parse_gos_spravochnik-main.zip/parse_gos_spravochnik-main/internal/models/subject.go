package models

type subject struct {
	Pid string 		`json:"pid"`// - ID участника
	Bin string 		`json:"bin"` // - БИН
	Iin string 		`json:"iin"`// - ИИН
	Inn string 		`json:"inn"`//- ИНН
	Unp string 		`json:"unp"`//- УНП
	Regdate string`json:"regdate"`	// - Дата свидетельства о государственной регистрации
	Crdate  string	`json:"crdate"` //- Дата регистрации
	Index_date string	`json:"index_date"`//- Дата индексации
	Number_reg string 	`json:"number_reg"` //- Номер свидетельства о государственной регистрации
	Series string 	`json:"series"`//- Серия свидетельства (для ИП)
	Name_ru string 	`json:"name_ru"` //- Наименование на русском языке
	Name_kz  string	`json:"name_kz"`//- Наименование на казахском языке
	Full_name_ru string	`json:"full_name_ru"` //- Полное наименование на русском языке
	Full_name_kz string	`json:"full_name_kz"`//- Полное наименование на казахском языке
	Country_code string	`json:"country_code"`//- Страна по ЭЦП
	Customer string 		`json:"customer"`//- Флаг Заказчик (1 - да 0 - Нет)
	Organizer string 		`json:"organizer"`//- Флаг Организатор (1 - да 0 - Нет)
	Mark_national_company string 		`json:"mark_national_company"`//- Флаг Национальная компания (1 - да 0 - Нет)
	Ref_kopf_code string	`json:"ref_kopf_code"`//- Код КОПФ
	Mark_assoc_with_disab string 		`json:"mark_assoc_with_disab"`//- Флаг Объединение инвалидов (1 - да 0 - Нет)
	System_id string 		`json:"system_id"`//- ИД Системы
	Supplier string 		`json:"supplier"`//- Флаг Поставщик (1 - да 0 - Нет)
	Type_supplier string 		`json:"type_supplier"`// - Тип поставщика (1 - юридическое лицо 2 - физическое лицо 3 - ИП)
	Krp_code  string	`json:"krp_code"`//- Размерность предприятия (КРП)
	Oked_list string	`json:"oked_list"` //- ОКЭД
	Kse_code string	`json:"kse_code"`//- Код сектора экономики
	Mark_world_company string 		`json:"mark_world_company"`//- Флаг Международная организация (1 - да 0 - Нет)
	Mark_state_monopoly string 		`json:"mark_state_monopoly"`//- Флаг Субъект государственной монополии (1 - да 0 - Нет)
	Mark_natural_monopoly string 		`json:"mark_natural_monopoly"` // - Флаг Субъект естественной монополии (1 - да 0 - Нет)
	Mark_patronymic_producer  string 		`json:"mark_patronymic_producer"` //- Флаг Отечественный товаропроизводитель (1 - да 0 - Нет)
	Mark_patronymic_supplyer  string 		`json:"mark_patronymic_supplyer"`//- Флаг Отечественный поставщик (1 - да 0 - Нет)
	Mark_small_employer string 	`json:"mark_small_employer"`//- Флаг Субъект малого предпринимательства (СМП) (1 - да 0 - Нет)
	Is_single_org  string 			`json:"is_single_org"`//- Флаг Единый организатор (1 - да 0 - Нет)
	Email string				`json:"email"`//- E-Mail
	Phone string				`json:"phone"`//- Телефон
	Website string				`json:"website"`//- Web сайт
	Last_update_date string		`json:"last_update_date"`// - Дата последнего редактирования
	Qvazi string					`json:"qvazi"`//- Флаг Квазисектора
	Year string					`json:"year"`//- Год регистрации
	Mark_resident string			`json:"mark_resident"`//- Флаг резидента
}

type SubjectRespSt struct {
	Total    int     	`json:"total"`
	Limit    int     	`json:"limit"`
	NextPage *string 	`json:"next_page"`
	Items    []*subject `json:"items"`
}
