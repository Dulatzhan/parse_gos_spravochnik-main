package models

type FkrbSubprogram struct {
	ID     int    `json:"id"`
	Ppr    string `json:"ppr"`
	NameRU string `json:"name_ru"`
	NameKZ string `json:"name_kz"`
}

type FkrbSubprogramResp struct {
	Total    int               `json:"total"`
	Limit    int               `json:"limit"`
	NextPage *string           `json:"next_page"`
	Items    []*FkrbSubprogram `json:"items"`
}
