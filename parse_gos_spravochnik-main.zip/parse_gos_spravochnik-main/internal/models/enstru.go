package models

type Enstru struct {
	ParentID int    `json:"parent_id"`
	DescKZ   string `json:"desc_kz"`
	DescRU   string `json:"desc_ru"`
	NameKZ   string `json:"name_kz"`
	NameRu   string `json:"name_ru"`
	Level    int    `json:"level_"`
	ID       int    `json:"id"`
	R        int    `json:"r"`
	G        int    `json:"g"`
	S        int    `json:"s"`
	Code     string `json:"code"`
	Edizm    string `json:"edizm"`
	Mkei     int    `json:"mkei"`
}

type EnstruResp struct {
	Total    int       `json:"total"`
	Limit    int       `json:"limit"`
	NextPage *string   `json:"next_page"`
	Items    []*Enstru `json:"items"`
}
