package models

type Ekrb struct {
	Code   string `json:"code"`
	NameRU string `json:"name_ru"`
	NameKZ string `json:"name_kz"`
	ID     int    `json:"id"`
}

type EkrbRespSt struct {
	Total    int     `json:"total"`
	Limit    int     `json:"limit"`
	NextPage *string `json:"next_page"`
	Items    []*Ekrb `json:"items"`
}
