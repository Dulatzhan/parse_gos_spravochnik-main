package models

type rnu struct {
	Pid string    `json:"pid"` // - ID участника
	Supplier_biin string `json:"supplier_biin"`  // - БИН/ИИН Участника
	Supplier_innunp string `json:"supplier_innunp"` //- ИНН/УНП Участника
	Supplier_name_ru string `json:"supplier_name_ru"`  //- Наименование участника на русском языке
	Supplier_name_kz string `json:"supplier_name_kz"` 	//- Наименование участника на казахском языке
	Kato_list string `json:"kato_list"` 	//- Массив кодов КАТО
	Index_date string `json:"index_date"`  //- Дата индексации объекта
	System_iditem string `json:"system_iditem"` //- Идентификатор системы
	}

type RnuRespSt struct {
	Total    int       `json:"total"`
	Limit    int       `json:"limit"`
	NextPage *string   `json:"next_page"`
	Items    []*rnu `json:"items"`
}
